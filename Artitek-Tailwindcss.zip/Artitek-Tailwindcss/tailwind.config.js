module.exports = {
  mode: 'jit',
  purge: ['./*.html'],
  darkMode: false,
  corePlugins: {
    container: true
  },
  plugins: [
    function ({ addComponents }) {
      addComponents({
        '.container': {
          maxWidth: '100%',
          '@screen sm': {
            maxWidth: '1920px',
          },
          '@screen md': {
            maxWidth: '1920px',
          },
          '@screen lg': {
            maxWidth: '1920px',
          },
          '@screen xl': {
            maxWidth: '1920px',
          },
          '@screen 2xl': {
            maxWidth: '1920px',
          },
        }
      })
    }
  ],
  theme: {
    extend: {
      container: {
        center: true,
        padding: {
          DEFAULT: '0',
          sm: '0',
          lg: '0',
          xl: '2.5rem',
          '2xl': '10%',
        },
      },
    },
  },
  // Other stuff 
};
