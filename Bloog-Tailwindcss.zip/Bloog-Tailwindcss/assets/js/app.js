


/*
=====================
JS Table of Conttent 
=====================
*/
(function ($) {
  "use strict";


  /*
  =====================
  JS Mobile Menu
  =====================
  */

  $('.slimmenu').slimmenu(
    {
      resizeWidth: '991',
      collapserTitle: ' ',
      animSpeed: 'medium',
      easingEffect: null,
      indentChildren: false,
      childrenIndenter: '&nbsp;'
    })

  /*
  =====================
  JS Carousel Menu
  =====================
  */

  $('.owl-carousel1').owlCarousel({
    loop: true,
    margin: 46,
    dots: false,
    nav: true,
    items: 1,
    navText: ['<button class="prev"><img src="assets/images/left-arrow.svg" alt="title"></button>', '<button class="next"><img src="assets/images/right-arrow.svg" alt="title"></button>'],
  })

  $('.owl-carousel2').owlCarousel({
    loop: true,
    margin: 46,
    dots: true,
    nav: false,
    responsiveClass: true,
    navText: ['<button class="prev"><img src="assets/images/left-arrow.svg" alt="title"></button>', '<button class="next"><img src="assets/images/right-arrow.svg" alt="title"></button>'],
    responsive: {
      0: {
        items: 1,
      },
      600: {
        items: 2,
      },
      1000: {
        items: 3,
      }
    }
  })


}(jQuery));
