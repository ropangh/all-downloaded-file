module.exports = {
  mode: 'jit',
  purge: ['./*.html'],
  darkMode: false,
  corePlugins: {
    container: true
  },
  plugins: [
    function ({ addComponents }) {
      addComponents({
        '.container': {
          maxWidth: '100%',
          '@screen sm': {
            maxWidth: '767px',
          },
          '@screen md': {
            maxWidth: '991px',
          },
          '@screen lg': {
            maxWidth: '991px',
          },
          '@screen xl': {
            maxWidth: '1140px',
          },
        }
      })
    }
  ],
  theme: {
    extend: {
      container: {
        center: true,
        padding: '1rem',
      },
    },
  },
  // Other stuff 
};

 