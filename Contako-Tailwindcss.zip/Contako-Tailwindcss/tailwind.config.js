module.exports = {
  mode: 'jit',
  purge: ['./*.html'],
  darkMode: false,
  corePlugins: {
    container: true
  },
  plugins: [

  ],
  theme: {
    extend: {
      screens: {
        'sm': '590px',
        'md': '800px',
      },
      container: {
        center: true,
        padding: '1rem',
      },
    },
  },
  // Other stuff 
};
 