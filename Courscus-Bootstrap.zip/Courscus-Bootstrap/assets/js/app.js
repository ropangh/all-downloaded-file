


/*
=====================
JS Table of Conttent 
=====================
*/
(function ($) {
  "use strict";


  /*
  =====================
  JS Mobile Menu
  =====================
  */

  $('.slimmenu').slimmenu(
    {
      resizeWidth: '991',
      collapserTitle: ' ',
      animSpeed: 'medium',
      easingEffect: null,
      indentChildren: false,
      childrenIndenter: '&nbsp;'
    })

  /*
  =====================
  JS Swiper Slider
  =====================
  */

  var swiper = new Swiper(".authorSwiper", {
    slidesPerView: "auto",
    centeredSlides: false,
    spaceBetween: 24,
    pagination: {
      el: ".swiper-pagination",
    },
    breakpoints: {
      '991': {
        slidesPerView: 2,
      },
      '1200': {
        slidesPerView: 3,
      },
    },
  });

}(jQuery));
