module.exports = {
  mode: 'jit',
  purge: ['./*.html'],
  darkMode: false,
   corePlugins: {
    container: true 
  },
    plugins: [

  ], 
  theme: {
    extend: {
      container: { 
        center: true,
        padding: '1rem',
       }, 
      colors: {
        "yellow-800": "#F9FF7F",   
        "blue-800": "#113238",   
        "blue-600": "#2a3b3e",     
        "gray-600": "#422b2b",   
        "gray-500": "#171717",    
        "gray-400": "#2C2D33",   
        "gray-300": "#737791",   
        "gray-200": "#6A7178",   
        "gray-100": "#CED4DA",        
      },
      spacing: {
        '2': '0.563rem',
        '4': '1.125rem',
        '14': '3.375rem',
      },
      borderRadius: { 
        'large': '50px',
      },
      fontSize: {  
        'xss': '0.56rem',
        '15xl': '18.875rem',
       },
       width: {
        '14': '3.375rem',
        '20': '4.5rem', 
      },
       height: {   
        '11': '2.625rem',
        '14': '3.375rem',
        '20': '4.5rem',   
      },
      boxShadow: {
        'DEFAULT': 'inset 0px -1px 0px #CED4DA;',
        'sm': '0px 4px 4px rgba(0, 0, 0, 0.25)',
        'md': '1.84604px 1.84604px 9.23021px rgba(116, 116, 116, 0.25)',
      }
    },
  },
  // Other stuff
};
