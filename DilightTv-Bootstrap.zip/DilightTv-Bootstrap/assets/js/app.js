/*
=====================
JS Table of Conttent 
=====================
*/
(function ($) {
  "use strict";

  /*
------------------------  
24. Toggle-Class
--------------------------
*/

  $('.mobile-sidebar-menu .dropdown-toggle').on('click', function (e) {
    $(this).parent().children('.dropdown-menu').slideToggle();
    e.preventDefault();
  });

  $('.navbar-toggler').on('click', function (e) {
    $('.navbar-toggler').toggleClass('open');
    $('.mobile-sidebar-menu').toggleClass("open"); 
    e.preventDefault();
  });

  /*
------------------------  
24. Swiper-Class
--------------------------
*/

  var swiper = new Swiper(".testiSwiper", {
    slidesPerView: 1,
    spaceBetween: 3,
    spaceBetween: 40,
    showsPagination: false,
    autoplay: {
      delay: 5000,
    },
    breakpoints: {
      640: {
        slidesPerView: 1,
      },
      991: {
        slidesPerView: 2,
      },
      1600: {
        slidesPerView: 3,
      },
    },
  });


}(jQuery)); 
