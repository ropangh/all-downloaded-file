/*
=====================
JS Table of Conttent 
=====================
*/
(function ($) {
  "use strict";
  /*
------------------------  
24. Swiper-Class
--------------------------
*/

  var swiper = new Swiper(".offerSwiper", {
    slidesPerView: 1,
    spaceBetween: 3,
    centeredSlides: true,
    showsPagination: false,
    breakpoints: {
      540: {
        slidesPerView: 1,
      },
      640: {
        slidesPerView: 2,
      },
      991: {
        slidesPerView: 3,
      },
    },
  });




}(jQuery)); 
