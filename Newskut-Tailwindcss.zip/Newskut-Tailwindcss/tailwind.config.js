module.exports = {
  mode: 'jit',
  purge: ['./*.html'],
  darkMode: false,
   corePlugins: {
    container: true 
  },
    plugins: [

  ], 
  theme: {
    extend: {
      container: { 
        center: true,
        padding: '1rem',
       },  
      boxShadow: {
        'xl': '0px 4px 32px 0px rgba(0, 0, 0, 0.06)', 
      }, 

    },
  },
  // Other stuff 
};

 