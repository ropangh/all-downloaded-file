module.exports = {
  mode: 'jit',
  purge: ['./*.html'],
  darkMode: false,
   corePlugins: {
    container: true 
  },
    plugins: [

  ], 
  theme: {
    extend: {
      container: { 
        center: true,
        padding: '1rem',
       },  
      colors: {       
      }, 
      maxWidth: {
        'xs': '18rem', 
        'sm': '22rem',  
      },   

    },
  },
  // Other stuff 
};

 