module.exports = {
  mode: 'jit',
  purge: ['./*.html'],
  darkMode: false,
   corePlugins: {
    container: true 
  },
    plugins: [

  ], 
  theme: {
    extend: {
      container: { 
        center: true,
        padding: '1rem',
       }, 
    },
  },
  // Other stuff 
};

