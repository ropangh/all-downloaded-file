(function ($) {
  "use strict";
  /*
  ------------------------  
   Scrolling Slide
  --------------------------   */
  if (window.innerWidth > 1180) {
  const slider = $(".section-slider");
  slider
    .slick({
      infinite: true,
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows: true,
      dots: false,
      autoplay: false,
      prevArrow: $('.slick-prev'),
      nextArrow: $('.slick-next')
    });

  slider.on('wheel', (function (e) {
    e.preventDefault();

    if (e.originalEvent.deltaY < 0) {
      $(this).slick('slickNext');
    } else {
      $(this).slick('slickPrev');
    }
  }));
}

})(jQuery);
