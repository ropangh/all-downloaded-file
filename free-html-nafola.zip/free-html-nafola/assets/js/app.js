/*
=====================
JS Table of Conttent 
=====================

*/
(function ($) {
  "use strict";
  /*
  ------------------------  
   Slider
  --------------------------
  */
  $('.gallery-slider').slick({
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    dots: true,
    autoplay: true,
    autoplaySpeed: 1000,
  })

})(jQuery);
